// pnpm 10.14.0 distribution placeholder; bytes are only hashed.
