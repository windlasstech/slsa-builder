// pnpm 11.28.3 distribution placeholder; bytes are only hashed.
